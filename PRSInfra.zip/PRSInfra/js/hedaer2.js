document.getElementById("common-header2").innerHTML = `
    
`;
